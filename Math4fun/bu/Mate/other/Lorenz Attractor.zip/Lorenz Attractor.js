
/* global windowHeight, WEBGL, windowWidth, mouseIsPressed, pwinMouseX, pwinMouseY */
/*Estuardo Diaz (2017-06-15)*/
var n = 3;
var c = 7;
var attractors = [];
var r = {x:0,y:0,z:0};
var bgcolor = 51;
var mx = my = 0;
var active = true;
var rotate = true;

var sketch = function(p) {
    p.setup = function(){
        p.createCanvas(p.windowWidth-100, p.windowHeight-100, p.WEBGL);
        p.background(0);
        for(var i = 0; i < n; i++){
            attractors.push({a:10,b:28,c:8/3,
                            dt:1,t:0,
                            x:0,y:0,z:0,
                            v:[],
                            color:p.color(255,255,255,100),
                            setTime:function(t){this.dt = t;},
                            setVar:function(va,vb,vc){this.a = va; this.b = vb; this.c = vc;},
                            setPos:function(px,py,pz){this.x = px; this.y = py; this.z = pz;},
                            reset:function(){this.x = 0; this.y = 0; this.z = 0; this.v = []; this.t = 0;},
                            randomize:function(){this.x = p.random()*100; this.y = p.random()*100; this.z = p.random()*100;},
                            setColor:function(r,g,b,h){this.color = p.color(r,g,b,h);},
                            advance2:function(){
                                this.x += ((-1*(this.x/2 +0.25)*Math.cos(Math.PI*this.x)) + 0.25)*this.dt;
                                this.y += this.dt;
                                this.v.push([this.x,this.y,this.z]);
                                this.t += this.dt;},
                            advance:function(){
                                this.x += this.dt*this.a*(this.y - this.x);
                                this.y += this.dt*(this.x*(this.b-this.z) - this.y);
                                this.z += this.dt*(this.x*this.y - this.c*this.z);
                                this.v.push([this.x,this.y,this.z]);
                                this.t += this.dt;},
                            draw:function(){
                                p.fill(this.color);
                                p.beginShape();
                                for(var i = 0; i < this.v.length; i++){
//                                    p.vertex(this.v[i][0]*100-100,this.v[i][1]*100-100,this.v[i][2]);
                                    p.vertex(this.v[i][0],this.v[i][1],this.v[i][2]);
                                }
                                p.endShape();},
                            getPos:function(a){return '('+this.x.toFixed(a)+','+this.y.toFixed(a)+','+this.z.toFixed(a)+')';}});
            attractors[i].reset();
            attractors[i].setPos(4,1,1+i*0.1);
//            attractors[i].randomize();
            attractors[i].setColor(50*  i,50*i,255-50*i,250);
            attractors[i].setTime(0.01);
        }
    };
    
    p.draw = function() {
        p.background(bgcolor);
        p.scale(c);
        myRotate(r,p);
        drawAxis(p);
        if(active){
            attractors.forEach(function(item,index){
                item.advance();
            });
        }
        attractors.forEach(function(item,index){
            item.draw();
        });
    };
    
    p.mousePressed = function() {
      mx = p.pwinMouseX;
      my = p.pwinMouseY;
    };
    
    p.mouseWheel = function(event) {
        if(true){
            if(c > event.delta*0.01){c -= event.delta*0.01;}
        }
    };
};

new p5(sketch, 'container');

function drawAxis(p){
    p.fill(255,255,255,100);
    p.beginShape();p.vertex(100,0,0);p.vertex(-100,0,0);p.endShape();
    p.beginShape();p.vertex(0,100,0);p.vertex(0,-100,0);p.endShape();
    p.beginShape();p.vertex(0,0,100);p.vertex(0,0,-100);p.endShape();
}

function myRotate(r,p){
    if(p.mouseIsPressed){
        r.y += (p.pwinMouseX - mx)*0.01;
        r.x -= (p.pwinMouseY - my)*0.01;
    }
    else if(rotate){
        r.x += 0.1;
        r.y += 0.1;
        r.z += 0.1;
    }
    p.rotateX(p.radians(r.x));
    p.rotateY(p.radians(r.y));
    p.rotateZ(p.radians(r.z));
}

function stop(){active = !active;};

function stopRotate(){rotate = !rotate;}

function reset(){
    attractors.forEach(function(item,index){
        item.reset();
        item.setPos(1,1,1+index*0.1);
    });
//    active = rotate = true;
}

function randomize(){
    attractors.forEach(function(item,index){
        item.reset();
        item.randomize();
    });
    active = rotate = true;
}

function advance(t){
    attractors.forEach(function(item,index){
        var ti = item.t;
        while(item.t < ti + t){
            item.advance();
        }
    });
}

function getPos(){
    alert(attractors[0].getPos(4));
}